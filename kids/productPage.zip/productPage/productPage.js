
    import { header,fonts } from '../components/header.js'
    import { append } from '../components/append.js'
let head = document.getElementById('header')
head.innerHTML = header();
let font = document.getElementById('fonts')
font.innerHTML = fonts();

let data  = JSON.parse(localStorage.getItem('item'))
console.log(data)

let container = document.getElementById('container')

let img1 = document.getElementById('img1')
img1.src = data.img1

let img2 = document.getElementById('img2')
img2.src = data.img2

let details = document.querySelector('#details>div')

let brand = document.createElement('h2')
brand.innerText = data.brand;

let category = document.createElement('p')
category.innerText = data.category;

let priceDiv = document.createElement('div')


let prices = JSON.parse(localStorage.getItem('prices'))
console.log(prices)

let price = document.createElement('h3')
price.innerText = prices.price;
price.id = 'price'

let discount = document.createElement('span')
 discount.innerText = prices.discount;
    discount.id = 'discount'
    
 let finalPrice = document.createElement('span')
 finalPrice.innerText = prices.finalPrice
 finalPrice.id = 'finalPrice'
        
let pr = document.createElement('p')
pr.innerText = "(Import duties included)"

priceDiv.append(price,discount,finalPrice,pr)
priceDiv.id = 'priceDiv'


// priceDiv.append(price,pr)
// priceDiv.id = 'priceDiv'

details.append(brand,category,priceDiv)

let img = document.querySelector('#tDetails>img')
img.src = data.img2;

let title = document.getElementById('title')
title.innerText = data.brand;

let detailCat = document.getElementById('detailCat')
detailCat.innerText = data.category;

let desc = document.getElementById('desc')
desc.innerText = data.desc;

let products = JSON.parse(localStorage.getItem('products'))
console.log(products)

let product = products.filter(el=>{
    if(data.type == el.type){
        return el;
    }
})
let recommended = product.splice(0,8)

append(recommended,container)

let middleFooter = document.getElementById('middleFooter')
middleFooter.addEventListener('click',function(){
    window.location.href = "https://www.farfetch.com/in/shopping/women/briston-watches/items.aspx?msc=briston_w_may22&mktref=display_w"

})


// brand: "VEJA"
// category: "Venturi suede sneakers"
// desc: "These Venturi sneakers from VEJA have been crafted from environmentally friendly and sustainable materials. They showcase a panelled design reminiscent of sports footwear from the '70s and sit atop a sturdy sole made of wild rubber from the Amazonian forest."
// id: 42
// img1: "https://cdn-images.farfetch-contents.com/16/94/49/31/16944931_34978752_1000.jpg"
// img2: "https://cdn-images.farfetch-contents.com/16/94/49/31/16944931_34980323_1000.jpg"
// price: 267
// type: "shoes"

